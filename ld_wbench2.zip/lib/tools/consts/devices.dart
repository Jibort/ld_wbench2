// Constants associades a dispositius específics.
// CreatedAt: 2025/02/12 dc. JIQ

import 'package:flutter/material.dart';

const Size iPhone8PlusSize = Size(414.0, 736.0);