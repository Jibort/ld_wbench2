const Map<String, String> ptMap = {
  "sabinaApp": "Aplicativo Sabina",
    "sabinaWelcome": "Bem-vindo a Sabina.",
};