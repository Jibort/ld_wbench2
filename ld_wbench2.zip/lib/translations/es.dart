const Map<String, String> esMap = {
  "sabinaApp": "Aplicación Sabina",
  "sabinaWelcome": "Bienvenido/a a Sabina."
};