const Map<String, String> caMap = {
  "sabinaApp": "Aplicació Sabina",
  "sabinaWelcome": "Benvingut/da a Sabina."
};