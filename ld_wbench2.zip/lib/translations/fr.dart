const Map<String, String> frMap = {
  "sabinaApp": "Application Sabina",
  "sabinaWelcome": "Bienvenue à Sabina.",
};