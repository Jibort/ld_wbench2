// Widget del Botó genèric de l'aplicació.
// CreatedAt: 2025/02/19 dc. JIQ

import 'package:ld_wbench2/core/ld_widget.dart';

class LdButton 
extends LdWidget {
  LdButton({
    super.key, 
    required super.pState, 
    required super.pVCtrl,
  });


  
}